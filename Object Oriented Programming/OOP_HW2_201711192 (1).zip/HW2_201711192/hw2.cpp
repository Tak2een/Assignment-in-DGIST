////////////////////////////////////////////////////////////////////////////////
// SE271 - Assignment 2: Source file
// 1. Complete the implementation of VariableList
// 2. You can add your implementation only in "IMPLEMENT HERE" & "CHANGE HERE"
//    Do not touch other lines; but you can change main() for testing
////////////////////////////////////////////////////////////////////////////////
#include "hw2.h"
#include <cstring>
#include <iostream>

////////////////////////////////////////////////////////////////////////////////
// You may also want to have additional functions, 
// e.g., static functions or forward declaration of functions, Then
//
// IMPLEMENT HERE
//
// NOTE: DO NOT USE global, static variables
////////////////////////////////////////////////////////////////////////////////

// Constructors
VariableList::VariableList() {
	size = 1;
	num = 0;
	this->array = new std::string[size];
	this->type = new DataType[size];
    // IMPLEMENT HERE
}
VariableList::VariableList(const int* initialArray, const int intsize) {
	this->size = intsize;
	this->array = new std::string[size];
	this->type = new DataType[size];
	this->num = 0;
	for(int i = 0; i < intsize; i++)
	{
		this->add(initialArray[i]);
		this->type[i] = DataType::Integer;
	}
}
VariableList::VariableList(const float* initialArray, const int intsize) {
    this->size = intsize;
    this->array = new std::string[size];
    this->type = new DataType[size];
    this->num = 0;
    for(int i = 0; i < intsize; i++)
    {
        this->add(initialArray[i]);
        this->type[i] = DataType::Float;
    }

}
VariableList::VariableList(const std::string* initialArray, const int intsize) {
    this->size = intsize;
    this->array = new std::string[size];
    this->type = new DataType[size];
    this->num = 0;
    for(int i = 0; i < intsize; i++)
    {
        this->add(initialArray[i]);
        this->type[i] = DataType::Str;
    }

}

// Destructor
// Note: Please delete(free) the memory you allocated 
VariableList::~VariableList() {
}

// Member functions
// add: Add the value at the end of the list
void VariableList::add(const int val) {
    if (size == num)
    {
        std::string *arraytmp = new std::string[size * 2];
		DataType *typetmp = new DataType[size * 2];
        memcpy(arraytmp, array, size*sizeof(std::string));
        memcpy(typetmp, type, size*sizeof(DataType));
        size *= 2;
        array = arraytmp;
        type = typetmp;
    }
	array[num] = std::to_string(val);
	type[num] = DataType::Integer;
	num++;
}
void VariableList::add(const float val) {
    if (size == num)
    {
        std::string *arraytmp = new std::string[size * 2];
		DataType *typetmp = new DataType[size * 2];
        memcpy(arraytmp, array, size*sizeof(std::string));
        memcpy(typetmp, type, size*sizeof(DataType));
        size *= 2;
        array = arraytmp;
        type = typetmp;
    }
	array[num] = std::to_string(val);
	type[num] = DataType::Float;
    num++;
}

void VariableList::add(const std::string& val) {
    if (size == num)
	{
		std::string *arraytmp = new std::string[size * 2];
		DataType *typetmp = new DataType[size * 2];
		memcpy(arraytmp, this->array, size*sizeof(std::string));
		memcpy(typetmp, this->type, size*sizeof(DataType));
		size *= 2;
		array = arraytmp;
		type = typetmp;
	}
    array[num] = val;
    type[num] = DataType::Str;
    num++;
}

// append: Copy all values of varList and append them at the end of the list
void VariableList::append(const VariableList& varList) {
	for(int i = 0; i < varList.num; i++)
	{
		if(varList.type[i] == DataType::Integer) this->add(stoi(varList.array[i]));
		else if(varList.type[i] == DataType::Float) this->add(stof(varList.array[i]));
		else this->add(varList.array[i]);
	}
}

// replace: replace the value at the given index in the list
bool VariableList::replace(const int idx, const int val) {
    if(idx > num - 1) return false;
	array[idx] = std::to_string(val);
	type[idx] = DataType::Integer;
	return true;
}

bool VariableList::replace(const int idx, const float val) {
	if(idx > num - 1) return false;
    array[idx] = std::to_string(val);
    type[idx] = DataType::Float;
    return true;

}
bool VariableList::replace(const int idx, const std::string& val) {
    if(idx > num - 1) return false; 
    array[idx] = val;
    type[idx] = DataType::Str;
    return true;

}

// remove: remove the item at the given index in the list
bool VariableList::remove(const int idx) {
	if(idx > num-1) return false;
    // IMPLEMENT HERE
	for(int i = idx; i < num-1; i++)
	{
		array[i] = array[i+1];
		type[i] = type[i+1];
	}
	num--;
    return true; // CHANGE HERE
}

// getSize: return the number of elements of the List
unsigned int VariableList::getSize() const {
    return num;
}

// getType: return the data type for the value at the given index
DataType VariableList::getType(const int idx) const {
    return type[idx];
}

// getValue: copy the value to the variable
bool VariableList::getValue(const int idx, int& val) const {
    // IMPLEMENT HERE
	if(idx > num - 1 or type[idx] != DataType::Integer)
    {
        return false;
    }
	val = stoi(array[idx]);

	return true;
}
bool VariableList::getValue(const int idx, float& val) const {
    // IMPLEMENT HERE
	if(idx > num - 1 or type[idx] != DataType::Float)
    {
        return false;
    }
	
	val = stof(array[idx]);

    return true;

}
bool VariableList::getValue(const int idx, std::string& val) const {
    // IMPLEMENT HERE
	if(idx > num - 1 or type[idx] != DataType::Str)
	{
		return false;
	}

	val = array[idx];

	return true;
}

////////////////////////////////////////////////////////////////////////////////
// You may also want to implement additional, private member functions here
// NOTE: DO NOT USE global, static variables
//
// IMPLEMENT HERE
//
////////////////////////////////////////////////////////////////////////////////
